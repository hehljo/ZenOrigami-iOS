import SwiftUI

/// Welcome back sheet showing offline earnings
struct WelcomeBackView: View {
    let offlineEarnings: Int
    let minutesOffline: Double
    @Environment(\.dismiss) private var dismiss

    var body: some View {
        VStack(spacing: 24) {
            Spacer()

            // Emoji animation
            Text("🚤")
                .font(.system(size: 80))
                .scaleEffect(1.2)
                .animation(.spring(response: 0.6, dampingFraction: 0.6).repeatForever(autoreverses: true), value: UUID())

            // Title
            Text("Welcome Back!")
                .font(.largeTitle.bold())

            // Offline time
            Text("You were away for")
                .font(.headline)
                .foregroundStyle(.secondary)
            Text(formatOfflineTime(minutesOffline))
                .font(.title2.bold())

            // Earnings
            VStack(spacing: 8) {
                Text("Your boat collected:")
                    .font(.subheadline)
                    .foregroundStyle(.secondary)

                HStack {
                    Text("💧")
                        .font(.system(size: 40))
                    Text("\(offlineEarnings)")
                        .font(.system(size: 48, weight: .bold, design: .rounded))
                        .monospacedDigit()
                }
            }
            .padding()
            .background(Color.blue.opacity(0.1))
            .clipShape(RoundedRectangle(cornerRadius: 20))

            Spacer()

            // Claim button
            Button {
                HapticFeedback.success()
                dismiss()
            } label: {
                Text("Claim Rewards")
                    .font(.headline)
                    .foregroundStyle(.white)
                    .frame(maxWidth: .infinity)
                    .padding()
                    .background(Color.blue)
                    .clipShape(RoundedRectangle(cornerRadius: 16))
            }
            .buttonStyle(.plain)
        }
        .padding(32)
        .interactiveDismissDisabled()
    }

    private func formatOfflineTime(_ minutes: Double) -> String {
        let hours = Int(minutes / 60)
        let mins = Int(minutes.truncatingRemainder(dividingBy: 60))

        if hours > 0 {
            return "\(hours)h \(mins)m"
        } else {
            return "\(mins)m"
        }
    }
}

#Preview {
    WelcomeBackView(offlineEarnings: 1234, minutesOffline: 125.5)
}
